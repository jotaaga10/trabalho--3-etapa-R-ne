from PROJETO import trb1


def mostrar_total_arrecadado():
    total_ingressos = sum(filmes[filme]['preco'] * ingressos_vendidos[filme] for filme in ingressos_vendidos)
    print(f"\nValor total arrecadado com as vendas dos ingressos: R${total_ingressos:.2f}")
    print(f"Valor total arrecadado com as vendas da lanchonete: R${total_vendas_lanchonete:.2f}")
    total = total_ingressos + total_vendas_lanchonete
    print(f"Valor total arrecadado: R${total:.2f}\n")


def mostrar_ingressos_vendidos():
    print("\nIngressos vendidos por filme:")
    for filme, quantidade in ingressos_vendidos.items():
        print(f'{filme.capitalize()}: {quantidade} ingresso(s) vendido(s)')


def mostrar_ingressos_filme():
    filme_escolhido = input('Digite o nome do filme: ').lower()
    if filme_escolhido in ingressos_vendidos:
        quantidade = ingressos_vendidos[filme_escolhido]
        print(f'\nQuantidade de ingressos vendidos para "{filme_escolhido.capitalize()}": {quantidade}')
    else:
        print('Filme não encontrado.')


def gerar_arquivo_ingressos_vendidos():
    filme_escolhido = input('Digite o nome do filme: ').lower()
    if filme_escolhido in ingressos_vendidos:
        quantidade = ingressos_vendidos[filme_escolhido]
        with open(f'{filme_escolhido}_ingressos_vendidos.txt', 'w') as arquivo:
            arquivo.write(f'Quantidade de ingressos vendidos para "{filme_escolhido.capitalize()}": {quantidade}')
        print(f'\nArquivo "{filme_escolhido}_ingressos_vendidos.txt" gerado com sucesso.')
    else:
        print('Filme não encontrado.')


def gerar_arquivo_ingressos_clientes():
    nome_filme = input('Digite o nome do filme: ').lower()
    if nome_filme in ingressos_vendidos:
        clientes_com_ingressos = []
        for cliente, info in usuarios.items():
            if len(info) > 3 and nome_filme in info[3]:
                clientes_com_ingressos.append((info[0], info[3][nome_filme]))

        if clientes_com_ingressos:
            with open(f'{nome_filme}_clientes_ingressos.txt', 'w') as arquivo:
                arquivo.write(f'Clientes que compraram ingressos para "{nome_filme.capitalize()}":\n')
                for cliente, ingressos_comprados in clientes_com_ingressos:
                    arquivo.write(f'{cliente}: {ingressos_comprados} ingresso(s)\n')
            print(f'\nArquivo "{nome_filme}_clientes_ingressos.txt" gerado com sucesso.')
        else:
            print('Nenhum cliente comprou ingressos para este filme.')
    else:
        print('Filme não encontrado.')


def listar_filmes_ordem_alfabetica():
    print('\nLista de filmes em ordem alfabética:')
    for filme in sorted(filmes.keys()):
        info = filmes[filme]
        print(f'{filme.capitalize()} - Sala: {info["sala"]} - Sessão: {info["sessao"]} - Preço: R${info["preco"]:.2f} - Capacidade: {info["capacidade"]}')


def mostrar_assentos_livres_filme():
    filme_escolhido = input('Digite o nome do filme: ').lower()
    if filme_escolhido in filmes:
        capacidade = filmes[filme_escolhido]['capacidade']
        ingressos_vendidos_filme = ingressos_vendidos[filme_escolhido]
        assentos_livres = capacidade - ingressos_vendidos_filme
        print(f'\nAssentos livres para "{filme_escolhido.capitalize()}": {assentos_livres}')
    else:
        print('Filme não encontrado.')

usuarios = {}

filmes = {
    'jurassic park': {'sessao': '15:00', 'preco': 15.00, 'sala': 1, 'capacidade': 100},
    'dragon ball': {'sessao': '18:00', 'preco': 12.00, 'sala': 2, 'capacidade': 80},
    'dune': {'sessao': '20:00', 'preco': 18.00, 'sala': 3, 'capacidade': 120},
    'star wars': {'sessao': '22:00', 'preco': 20.00, 'sala': 4, 'capacidade': 150}
}

total_vendas_ingressos = 0
total_vendas_lanchonete = 0

ingressos_vendidos = {filme: 0 for filme in filmes}

saldo = 0
while True:
    print('\nSEJA BEM VINDO(A) AO CINESERTÃO!!')
    print('\n------------------Menu-------------------\n')
    print('1-Menu de ADM')
    print('2-Menu do Cliente')
    print('3-Cadastrar usuário')
    print('0-Sair do sistema')

    opmenu_pr = int(input('\nDigite a opcao desejada: '))

    if opmenu_pr == 0:
        print('\n------------------------\nAgradecemos a interação \n    VOLTE SEMPRE!!\n------------------------')
        break

    elif opmenu_pr == 1:
        logado = False
        for chave in usuarios:
            if chave == login and usuarios[login][2] == senha:
                logado = True

        if logado:
            print("\n--Bem-vindo ao Menu de Administrador--")
            senha = input("Digite a senha do administrador: ")

            if senha == "joaokaue":
                print("Login bem-sucedido!\n")
                while opmenu_pr != 0:
                    print('\n1-Inserir filme')
                    print('2-Listar Filmes')
                    print('3-Buscar filmes')
                    print('4-Remover Filmes')
                    print('5-Atualizar Filmes')
                    print('6-Mostrar total arrecadado')
                    print('7-Mostrar ingressos vendidos')
                    print('8-Mostrar ingressos vendidos por filme específico')
                    print('9-Gerenciar arquivo de ingressos vendidos')
                    print('10-Mostrar assentos livres para filme específico')
                    print('0-Sair')
                    op = int(input('Digite a opcao desejada: '))

                    if op == 0:
                        print('Agradecemos por usar nosso serviço!')
                        break
                    if op == 1:
                        nome = input('Digite o nome do filme: ').capitalize()
                        sessao = input('Digite o horário da sessão: ')
                        preco = float(input('Digite o preço do filme: '))
                        sala = int(input('Digite o número da sala: '))
                        capacidade = int(input('Digite a capacidade máxima da sala: '))
                        filmes[nome.lower()] = {'sessao': sessao, 'preco': preco, 'sala': sala, 'capacidade': capacidade}
                        ingressos_vendidos[nome.lower()] = 0
                        print('\nFilme inserido com sucesso.\n')

                    elif op == 2:
                        print('Lista de filmes:')
                        for nome, info in filmes.items():
                            print(f'{nome.capitalize()} - Sala: {info["sala"]} - Sessão: {info["sessao"]} - Preço: R${info["preco"]:.2f} - Capacidade: {info["capacidade"]}')

                    elif op == 3:
                        busca = input('Digite o termo para buscar: ')
                        print('Resultados da busca:')
                        for nome, info in filmes.items():
                            if nome.lower().count(busca.lower()) > 0:
                                print(f'{nome.capitalize()} - Sala: {info["sala"]} - Sessão: {info["sessao"]} - Preço: R${info["preco"]:.2f} - Capacidade: {info["capacidade"]}')

                    elif op == 4:
                        busca = input('Digite o nome do filme para remoção: ').lower()
                        if busca in filmes:
                            del filmes[busca]
                            del ingressos_vendidos[busca]
                            print('Filme removido com sucesso.')
                        else:
                            print('Filme não encontrado.')

                    elif op == 5:
                        busca = input('Digite o nome do filme para atualizar: ').lower()
                        if busca in filmes:
                            novo_nome = input('Digite o novo nome para atualizar: ')
                            filmes[novo_nome.lower()] = filmes.pop(busca)
                            ingressos_vendidos[novo_nome.lower()] = ingressos_vendidos.pop(busca)
                            filmes[novo_nome.lower()]['sessao'] = input('Digite o novo horário da sessão: ')
                            filmes[novo_nome.lower()]['preco'] = float(input('Digite o novo preço do filme: '))
                            filmes[novo_nome.lower()]['sala'] = int(input('Digite o novo número da sala: '))
                            filmes[novo_nome.lower()]['capacidade'] = int(input('Digite a nova capacidade máxima da sala: '))
                            print('Filme atualizado com sucesso.')
                        else:
                            print('Filme não encontrado.')

                    elif op == 6:
                        mostrar_total_arrecadado()

                    elif op == 7:
                        mostrar_ingressos_vendidos()

                    elif op == 8:
                        mostrar_ingressos_filme()

                    elif op == 9:
                        gerar_arquivo_ingressos_clientes()

                    elif op == 10:
                        mostrar_assentos_livres_filme()

    elif opmenu_pr == 2:

        for chave in usuarios:

            if chave == login and usuarios[login][2] == senha:

                logado = True

                print('\n------------------Menu do cliente-------------------\n')

                print('1- Para Listar filmes')

                print('2- Para comprar os ingressos')

                print('3- Para acessar a loja')

                print('4- Para listar os ingressos comprados')

                print('5- Para listar os filmes em ordem alfabetica')

                print('6- Para gerar arquivo de ingressos comprados')

                print('7- Para avaliar nosso cinema')

                print('0- Sair do sistema')

                opmenu_pb = int(input('Digite a opção desejada: '))

                if opmenu_pb == 1:

                    print('Lista de filmes:')

                    for filme, info in filmes.items():
                        print(

                            f'{filme.capitalize()} - Sala: {info["sala"]} - Sessão: {info["sessao"]} - Preço: R${info["preco"]:.2f} - Capacidade: {info["capacidade"]}')

                elif opmenu_pb == 2:

                    saldo = float(input('Digite o saldo disponível para compras: '))

                    filme_escolhido = input('Digite o nome do filme que deseja assistir: ').lower()

                    if filme_escolhido in filmes:

                        preco_filme = filmes[filme_escolhido]['preco']

                        if saldo >= preco_filme:

                            num_ingressos = int(input(f'Digite o número de ingressos que deseja comprar para "{filme_escolhido.capitalize()}": '))

                            total_preco = preco_filme * num_ingressos

                            if total_preco <= saldo:

                                if filmes[filme_escolhido]['capacidade'] >= num_ingressos:

                                    saldo -= total_preco

                                    filmes[filme_escolhido]['capacidade'] -= num_ingressos

                                    ingressos_vendidos[filme_escolhido] += num_ingressos

                                    if login in usuarios:

                                        if len(usuarios[login]) < 4:

                                            usuarios[login].append({filme_escolhido: num_ingressos})

                                        else:

                                            usuarios[login][3][filme_escolhido] = num_ingressos

                                    else:

                                        usuarios[login] = [nome, perfil, senha, {filme_escolhido: num_ingressos}]

                                    print(f'\n{num_ingressos} ingresso(s) para "{filme_escolhido.capitalize()}" comprado(s) com sucesso!')

                                    print(f'Saldo restante: R${saldo:.2f}')

                                else:

                                    print('Capacidade da sala esgotada para este filme.')

                            else:

                                print('Saldo insuficiente para comprar o(s) ingresso(s).')

                        else:

                            print('Saldo insuficiente para comprar o ingresso.')

                    else:

                        print('Filme não encontrado na lista.')

                elif opmenu_pb == 3:
                    while True:

                        print('\n------------------Loja do Cinema-------------------\n')

                        print('Bem-vindo à nossa loja! Aqui estão os itens disponíveis:')

                        print('1 - Pipoca: R$10.00')

                        print('2 - Refrigerante: R$5.00')

                        print('3 - Salgadinho: R$8.00')

                        print('4 - Chocolate: R$7.00')

                        opcao_loja = input('Digite o número do item que deseja comprar ou 0 para voltar ao menu principal: ')

                        if opcao_loja == 0:
                            break

                        elif opcao_loja == 1:

                            total_vendas_lanchonete += 10.00

                            saldo -= 10.00

                            print('Pipoca adicionada ao carrinho. Saldo atualizado: R$', saldo)

                        elif opcao_loja == 2:

                            total_vendas_lanchonete += 5.00

                            saldo -= 5.00

                            print('Refrigerante adicionado ao carrinho. Saldo atualizado: R$', saldo)

                        elif opcao_loja == 3:

                            total_vendas_lanchonete += 8.00

                            saldo -= 8.00

                            print('Salgadinho adicionado ao carrinho. Saldo atualizado: R$', saldo)

                        elif opcao_loja == 4:

                            total_vendas_lanchonete += 7.00

                            saldo -= 7.00

                            print('compra adicionada ao carrinho. Saldo atualizado: R$', saldo)

                        else:

                            print('Opção inválida!')

                elif opmenu_pb == 4:
                    mostrar_ingressos_vendidos()

                elif opmenu_pb == 5:
                    listar_filmes_ordem_alfabetica()

                elif opmenu_pb == 6:
                    gerar_arquivo_ingressos_vendidos()

                elif opmenu_pb == 7:

                     print('deixe aqui uma nota de 1 a 5')
                     int(input('digite a nota aqui: '))
                     print('obrigado pela sua avalição, volte sempre !! <3')

    elif opmenu_pr == 3:

        print('\n---Cadastro de usuário---\n')

        nome = input('Digite seu nome completo: ')

        login = input('Digite seu login: ')

        senha = input('Digite sua senha: ')

        print('CADASTRO REALIZADO COM SUCESSO!!')

        perfil = int(input('Digite 1 para cliente do cinema ou 2 para administrador do cinema: '))

        usuarios[login] = [nome, perfil, senha]

    else:
        print('por favor coloque algo válido')