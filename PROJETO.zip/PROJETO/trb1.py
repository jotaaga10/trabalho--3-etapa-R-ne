def validar_texto(texto):
    return texto.strip() != ''